# PROMPT POUR L'AGENT IA — ARDOISE (Flutter / Android)

Tu es un développeur Flutter senior. Tu travailles sur le projet **ARDOISE** (suivi de dettes / prêts).
Ta mission : **améliorer l'UX, corriger les incohérences et intégrer un Motion Design cohérent.
NE FAIS PAS DE REFONTE COMPLÈTE.** Le résultat doit paraître plus mature et plus fluide,
pas surchargé d'animations.

## 0. Fichiers fournis (déjà écrits, à copier puis adapter)
```
lib/core/motion/     tokens + widgets d'animation (M01–M20)  -> importer via ardoise_motion.dart
lib/core/theme/      ardoise_shape.dart (rayons réduits)
lib/core/widgets/    empty_state, whatsapp_button, confirm_delete (+ undo)
lib/core/services/   friendly_error, reminder_service (alertes locales)
ANDROID_SETUP.md     manifest, gradle, pubspec pour les alertes
ardoise_motion_design.json   spec officielle (durées, courbes, déclencheurs)
```
Le code fourni n'a pas été compilé. Corrige imports, noms de package et incompatibilités de
version Flutter si `flutter analyze` en signale (les points sensibles sont commentés dans le code).

## 1. À CONSERVER ABSOLUMENT
Logique métier, base de données (schéma, migrations, requêtes), données existantes, fonctionnalités,
identité visuelle (couleurs, typographies, logo, textes sauf quand une consigne ci-dessous
demande de les changer), navigation principale. **Aucune migration destructive.**
On n'anime que l'affichage : jamais une valeur métier.

## 2. MÉTHODE OBLIGATOIRE (pour CHAQUE modification)
1. Identifier le widget/la page concerné(e) (chemin du fichier).
2. Lire et noter son comportement actuel.
3. Modifier uniquement ce qui est nécessaire (diff minimal, pas de reformatage de fichier entier).
4. Vérifier les régressions (navigation retour, état de formulaire, calculs, données).
Travailler par lots (voir §9) ; `flutter analyze` après chaque lot. Un commit par lot.

## 3. STYLE : PEU D'ARRONDIS
- Rayon maximum **6 px**. Boutons / champs / cartes : **4 px**. Bottom sheets : 6 px en haut seulement.
  Barres de progression : 2 px. Utiliser `AShape` et `applyArdoiseShape(theme)`.
- Supprimer les `StadiumBorder`, `CircleBorder` et rayons > 6 sur boutons, cartes, champs, puces, FAB.
  Seule exception : un avatar peut rester rond s'il l'est déjà.
- Aucune autre modification de couleur ou de typographie.

## 4. MOTION DESIGN (règles)
- Durées/courbes : **uniquement** via `AMotion` (issu du JSON). Jamais de valeur en dur.
- Animations natives Flutter uniquement. Pas de Lottie/GIF/vidéo.
- Aucune animation permanente (seule exception : pulsation du skeleton PENDANT un chargement).
- `MediaQuery.disableAnimations` respecté (déjà géré dans les widgets fournis ; le vérifier sur tout code ajouté).
- Pas de rebuild inutile : `child:` des AnimatedBuilder, `RepaintBoundary` sur barres/graphiques,
  `FadeSlideIn(enabled: index < 10)` dans les ListView.builder pour ne pas rejouer au scroll.
- Les animations ne bloquent jamais un tap (pas d'`IgnorePointer` pendant une animation).

### Correspondance M01–M20 → écran
| ID | Où | Comment |
|---|---|---|
| M01 | Splash | `SplashLogo` puis `ArdoiseRoute(fadeOnly: true)` |
| M02 | Accueil | `FadeSlideIn(index: 0..4)` : header, résumé, cartes, activité récente ; FAB scale 0.88→1 |
| M03 | tous boutons | `TapScale` (ou le brancher une fois dans un widget bouton commun) |
| M04 | navigation | `pageTransitionsTheme: ardoisePageTransitions` dans le ThemeData (1 ligne) |
| M05 | Personnes | `FadeSlideIn(offset: Offset(16,0), duration: 280ms, index: i)` |
| M06 | Fiche personne | `Hero(tag: 'person-<id>')` sur avatar/nom, contenu en `FadeSlideIn(offset: Offset(0,14))` |
| M07 | Nouvelle ligne | formulaire `FadeSlideIn(offset:(0,24))`, champs en stagger 45 ms |
| M08 | formulaires | `FocusLift` autour des champs + `focusedBorder` dans le thème |
| M09 | Paiement | `showArdoiseSheet` |
| M10 | après paiement | `SuccessCheck(label: 'Paiement enregistré')` |
| M11 | Fiche personne | `AnimatedAmount` (montant restant) + `DebtProgressBar` |
| M12 | dette soldée | `SuccessCheck(settled: true, label: 'Soldée')` dans un `AnimatedSwitcher` |
| M13 | Rappels | cloche scale 0.88→1.05→1 + carte `FadeSlideIn(offset:(0,10))` |
| M14 | WhatsApp | `WhatsAppButton` |
| M15 | Bilan | `AnimatedAmount(duration: AMotion.counter)` + blocs en fondu |
| M16 | Bilan graphique | `AnimationController` 650 ms ; révéler le tracé de gauche à droite (clip/progress dans le CustomPainter) ; dernier point mis en évidence |
| M17 | Réglages | `Switch` natif (déjà ~180 ms) — ne rien surcharger |
| M18 | PIN | `Shake(trigger: erreurs)` |
| M19 | Suppression | `RemovableItem` |
| M20 | États vides | `EmptyState` |

## 4 bis. SKELETONS (point 21)
Remplacer les `CircularProgressIndicator` de chargement de liste/Accueil par `PersonTileSkeleton`,
`SummarySkeleton`, ou un `Skeleton` + `SkeletonBox` de la forme du contenu final. Ne montrer un skeleton
que si le chargement dépasse ~150 ms (éviter le flash) ; sinon afficher directement le contenu.

## 5. LES 24 POINTS — consignes précises

**1. Nettoyer les fonctions techniques de l'UI.** Retirer de l'interface tout ce qui est technique
(écrans/boutons debug, JSON/DB brute, chemins de fichiers, logs, IDs, mentions "backup/migration/schema",
actions de test). Ne pas supprimer le code métier derrière : masquer derrière `kDebugMode`
ou le déplacer vers Réglages > Données si c'est une vraie fonction utilisateur (sauvegarde, export).

**2. Export CSV → Réglages > Données.** Retirer le bouton de son emplacement actuel ; le placer dans
Réglages > Données avec la MÊME fonction d'export. Libellé : « Exporter mes données (CSV) ».

**3. Accueil simplifié** autour de 4 blocs seulement : **À recevoir**, **À payer**, **En retard**,
**Activité récente** (5 dernières opérations, lien « Tout voir »). Retirer le reste de l'Accueil
(sans supprimer les fonctions : elles doivent rester accessibles ailleurs). Montants en `AnimatedAmount`.
« En retard » en couleur d'alerte de la palette existante.

**4. Bouton + = action principale.** FAB unique, toujours au même endroit sur Accueil et Personnes.
Étiqueter pour l'accessibilité (`tooltip: 'Ajouter'`). Scale 0.88→1 à l'apparition.

**5. Menu d'ajout simplifié.** 2 choix maximum au premier niveau, libellés actions :
« Nouvelle ligne (prêt / dette) » et « Nouvelle personne ». Pas de sous-menus. Bottom sheet via `showArdoiseSheet`.
Si on ajoute depuis une Fiche personne, la personne est pré-sélectionnée (aucun choix redemandé).

**6. États vides** (Accueil sans données, Personnes, historique, rappels, recherche sans résultat) :
`EmptyState` avec titre + 1 phrase + 1 action. Ex. Personnes : « Aucune personne » /
« Ajoutez la première pour suivre ce qu'on vous doit. » / [Ajouter une personne].
Recherche sans résultat : « Aucun résultat pour “…” » + action « Ajouter “…” ».

**7. Recherche des personnes améliorée.** Champ en haut de la liste, filtrage instantané en mémoire
(insensible à la casse ET aux accents, ex. « Aminata » = « aminata », « Zoé » = « zoe »), recherche aussi par numéro de téléphone,
debounce 150 ms, bouton effacer (×), conservation de la requête au retour depuis une fiche,
résultat avec surlignage optionnel. Ne pas modifier les requêtes SQL si le filtrage en mémoire suffit.

**8. Hiérarchie de la Fiche personne.** Ordre vertical : (1) en-tête nom + statut, (2) **montant restant**
en grand (`AnimatedAmount`) + `DebtProgressBar` + « payé X sur Y », (3) actions principales sur une ligne :
**Enregistrer un paiement** (bouton plein) · **Rappel / WhatsApp** (secondaire), (4) historique des opérations.
Infos secondaires (téléphone, notes) plus petites. Une seule action principale visible.

**9. Supprimer dans le menu secondaire.** Retirer le bouton Supprimer visible ; le placer dans un menu
« ⋮ » (PopupMenuButton) de l'AppBar de la fiche, en dernier, couleur d'erreur, séparé par un Divider.

**10. Enregistrer un paiement simplifié.** Bottom sheet avec : montant (clavier numérique, pré-rempli
avec le restant), bouton « Solde total » (raccourci), date (aujourd'hui par défaut, modifiable),
note optionnelle repliée. 1 bouton « Enregistrer ». Validation claire : montant > 0 et ≤ restant,
message sous le champ (pas de dialogue).

**11. Confirmation visuelle après paiement.** Après enregistrement : fermer le sheet, rester sur la Fiche
personne, afficher `SuccessCheck` (M10) brièvement (≈1,2 s, non bloquant, en overlay/bandeau) puis disparaître.

**12. Diminution du montant restant animée.** `AnimatedAmount` + `DebtProgressBar` : l'ancien restant glisse
vers le nouveau (600 ms). Aucun rechargement complet de la page : seul le widget concerné se reconstruit.

**13. État « dette soldée ».** Quand restant = 0 : l'en-tête passe en état « Soldée » (coche + libellé),
barre à 100 %, bouton « Enregistrer un paiement » masqué/remplacé par « Dette soldée », rappels désactivés pour
cette dette. M12 joué une seule fois au passage à 0 (pas à chaque ouverture : au simple affichage, état statique).

**14. Statuts uniformes.** Exactement 3 : **En cours**, **En retard**, **Soldée**. Un seul widget `StatusBadge`
(rayon 4, texte + couleur issue de la palette existante) utilisé PARTOUT (Accueil, listes, fiche, bilan, rappels).
Remplacer tout autre libellé (« Active », « Impayée », « Payée », « Terminé »…). Règle : soldée si restant = 0 ;
en retard si échéance dépassée et restant > 0 ; sinon en cours. Centraliser cette règle dans UNE fonction,
sans changer les données stockées (ne dériver que pour l'affichage).

**15. Rappels simplifiés.** Par dette : un interrupteur « Me rappeler » + choix de la date/heure
(raccourcis : Demain · Dans 3 jours · Dans 1 semaine · Date précise). Liste « Rappels » triée par date avec
M13. Supprimer les options techniques/superflues. Voir §6 pour les alertes.

**16. Action WhatsApp claire.** `WhatsAppButton` avec libellé « Envoyer le rappel sur WhatsApp » ;
message pré-rempli (nom, montant restant, échéance), aperçu du message AVANT envoi quand c'est possible.
Réutiliser la logique d'ouverture existante. Numéro absent → message clair « Ajoutez un numéro pour utiliser WhatsApp »
avec action « Ajouter un numéro ».

**17. Erreurs compréhensibles.** Tout `catch` visible par l'utilisateur passe par `showFriendlyError(context, e, action: '…')`.
Aucune stack trace, aucun `toString()` d'exception, aucun code d'erreur à l'écran.
Messages en français, ce qui s'est passé + quoi faire.

**18. Réglages par catégories.** Sections avec en-têtes : **Sécurité** (PIN, biométrie) · **Rappels** (notifications) ·
**Données** (export CSV, sauvegarde/restauration si existantes) · **Affichage** (si existant) · **À propos** (version).
Chaque ligne : titre + sous-titre court. Actions destructives (effacer les données) en bas de « Données », avec confirmation.

**19. Écran PIN/biométrie.** Clavier numérique propre, 4 (ou n) pastilles carrées de saisie, bouton biométrie
visible si disponible et activé, déclenchement automatique de la biométrie à l'ouverture (1 fois),
erreur : `Shake` + message « Code incorrect » + vibration légère (`HapticFeedback.mediumImpact`),
effacement automatique de la saisie après la secousse. Ne pas changer la logique de vérification du PIN ni son stockage.

**20. Suppression : confirmation + annulation.** Pour TOUTE suppression (ligne, paiement, personne) :
`confirmDelete` → `RemovableItem` (M19) → `showUndoSnack` (« Supprimé · Annuler », 5 s).
La suppression en base n'est faite qu'à `onCommit` (fermeture du snackbar sans annulation) ; `onUndo` restaure l'élément
dans l'état UI. Suppression d'une personne avec dettes : texte d'avertissement explicite (nombre de lignes concernées).

**21. Skeletons.** Voir §4 bis.

**22. Transitions de pages.** M04 via `pageTransitionsTheme` (global) ; Hero M06 ; sheets M09.

**23. Parcours.**
- *Nouvelle ligne → Fiche personne* : après enregistrement, ouvrir la **Fiche de la personne concernée**.
  Si le formulaire a été ouvert depuis l'Accueil/Personnes : `pushReplacement` vers la fiche (le retour ramène à la liste d'origine).
  S'il a été ouvert depuis la fiche de cette personne : `pop(true)` et rafraîchir.
- *Paiement → Fiche personne* : le sheet se ferme, l'utilisateur reste sur la fiche, qui se met à jour.

**24. Ne jamais renvoyer inutilement à l'Accueil.** Interdit après une action : `popUntil((r) => r.isFirst)`,
`pushAndRemoveUntil` vers l'Accueil, `pushNamedAndRemoveUntil('/')`, `Navigator.pop` multiples. Faire l'inventaire
(`grep -rn "popUntil\|pushAndRemoveUntil\|pushNamedAndRemoveUntil" lib/`) et ne garder le retour Accueil que
pour : déverrouillage PIN, fin de splash, et changement d'onglet explicite de l'utilisateur.
Le bouton retour système doit toujours ramener à l'écran précédent logique.

## 6. ALERTES DE RAPPEL « DÈS QUE LE MOMENT EST VENU »
Utiliser `ReminderService` (flutter_local_notifications + timezone) et appliquer `ANDROID_SETUP.md`.
1. `main()` : `await ReminderService.instance.init(onOpen: …)`. Au tap sur la notification (app ouverte ou fermée,
   `launchPayload()`), ouvrir la **Fiche personne** (payload `person:<id>`), pas l'Accueil.
2. Demander les permissions (`requestPermissions()`) au moment où l'utilisateur ACTIVE « Me rappeler » pour la
   première fois, avec une phrase d'explication avant la demande système. Refus → message clair + lien vers les réglages Android.
3. À chaque création/modification/suppression/désactivation d'un rappel, ET au démarrage, ET sur
   `AppLifecycleState.resumed` : `syncAll(rappelsActifs)` (construits depuis les données existantes ; ne pas changer le modèle).
4. Notification : titre « Rappel : <Nom> », corps « <montant restant> à recevoir/payer — échéance <date> ».
5. Rappel dont l'heure est passée sans avoir été notifié (téléphone éteint) : `showNow` à l'ouverture de l'app,
   une seule fois (mémoriser avec le mécanisme de stockage existant).
6. Dette soldée ou personne supprimée → annuler ses notifications.
7. Tester sur appareil réel : rappel dans 1 min app ouverte / en arrière-plan / app fermée / après redémarrage ;
   mode économie d'énergie ; Android 13+ (permission POST_NOTIFICATIONS) et 12+ (alarmes exactes).

## 7. ACCESSIBILITÉ & PERFORMANCE
- Cibles tactiles ≥ 48 dp ; contrastes inchangés ; `Semantics`/tooltips sur les boutons icônes.
- Pas de `Opacity` imbriquées sur de longues listes ; `const` partout où possible ; listes en `ListView.builder`.
- Tester avec « Supprimer les animations » activé (Android > Accessibilité) : plus aucun mouvement non essentiel.
- Profiler une liste de 300+ personnes/lignes : pas de jank au scroll.

## 8. RÈGLES DE SÉCURITÉ DU PROJET
- Pas de nouvelle dépendance hors : `flutter_local_notifications`, `timezone`, `flutter_timezone` (si absents).
- Pas de changement de `applicationId`, de signature, ni de `versionCode` sans demande.
- Ne jamais supprimer ni réécrire les données utilisateur. Toute opération de données non triviale = test unitaire.

## 9. ORDRE DE TRAVAIL (un commit par lot, analyze après chaque lot)
1. **Fondations** : copier `core/`, brancher `pageTransitionsTheme` + `applyArdoiseShape`, `TapScale` sur les boutons, rayons réduits.
2. **Accueil + FAB + menu d'ajout + états vides + skeletons** (points 3–6, 21 ; M01, M02, M20).
3. **Personnes + recherche + Fiche personne** (7–9, 14 ; M05, M06, M11).
4. **Paiement + dette soldée + parcours** (10–13, 23, 24 ; M09, M10, M12).
5. **Suppressions** (9, 20 ; M19).
6. **Rappels + WhatsApp + alertes** (15, 16, §6 ; M13, M14).
7. **Réglages + PIN + erreurs + nettoyage technique + Export CSV** (1, 2, 17–19 ; M17, M18).
8. **Bilan** (M15, M16) + passe finale d'homogénéité.

## 10. VALIDATION FINALE
```
flutter clean && flutter pub get
flutter analyze        # 0 erreur, 0 warning
flutter test           # tous les tests existants passent + tests ajoutés (statut, filtre accents, formatage)
flutter build apk --release
```
Vérifier manuellement : aucun overflow (petits écrans 360 dp, police agrandie), retour arrière partout,
formulaires qui conservent leur état, données existantes intactes après mise à jour de l'APK
(installer la nouvelle version PAR-DESSUS l'ancienne), mode animations réduites, alertes de rappel.

## 11. RAPPORT À FOURNIR À LA FIN
Tableau des 24 points : fait / partiel / non fait + fichiers modifiés ; liste des 20 motions et leur emplacement ;
résultats des 3 commandes ; régressions éventuelles ; points à valider sur appareil réel.
