# Android — configuration requise pour les alertes de rappel

## 1. pubspec.yaml (vérifier ce qui existe déjà, ne pas dupliquer)
```yaml
dependencies:
  flutter_local_notifications: ^19.0.0   # (déjà présent dans l'APK actuel, garder la version installée)
  timezone: ^0.10.0
  flutter_timezone: ^4.0.0
```

## 2. android/app/src/main/AndroidManifest.xml
Dans `<manifest>` (hors `<application>`) :
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
<uses-permission android:name="android.permission.VIBRATE"/>
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
```
Dans `<application>` :
```xml
<receiver android:exported="false"
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
<receiver android:exported="false"
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
  <intent-filter>
    <action android:name="android.intent.action.BOOT_COMPLETED"/>
    <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
    <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
    <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
  </intent-filter>
</receiver>
```

## 3. android/app/build.gradle(.kts) — desugaring (exigé par flutter_local_notifications)
```kotlin
android {
  compileOptions {
    isCoreLibraryDesugaringEnabled = true
    sourceCompatibility = JavaVersion.VERSION_11   // ou la valeur déjà en place
    targetCompatibility = JavaVersion.VERSION_11
  }
}
dependencies {
  coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
```
(Groovy : `coreLibraryDesugaringEnabled true` / `coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'`.)

## 4. Icône de notification
`@mipmap/ic_launcher` est utilisé par défaut. Idéal : ajouter une icône monochrome
`android/app/src/main/res/drawable/ic_stat_ardoise.png` et remplacer dans `ReminderService.init`.

## 5. main.dart
```dart
WidgetsFlutterBinding.ensureInitialized();
await ReminderService.instance.init(onOpen: (payload) { /* ouvrir la Fiche personne */ });
runApp(...);
```
