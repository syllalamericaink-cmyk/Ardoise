import 'package:flutter/material.dart';
import '../motion/ardoise_motion.dart';

/// M14 — bouton WhatsApp explicite. Libellé clair + icône.
/// Tap : scale 1→0.96→1, icône +2 px puis retour, puis état "Ouvert ✓" 1,5 s
/// sans bloquer l'interface.
///
/// `onPressed` doit contenir la logique d'ouverture DÉJÀ présente dans l'app
/// (url_launcher / wa.me). Ne pas la réécrire si elle existe.
class WhatsAppButton extends StatefulWidget {
  const WhatsAppButton({
    super.key,
    required this.onPressed,
    this.onError,
    this.label = 'Envoyer le rappel sur WhatsApp',
  });

  final Future<void> Function() onPressed;
  /// Appelé en cas d'échec (afficher friendlyError(e) dans un SnackBar).
  final void Function(Object error)? onError;
  final String label;

  @override
  State<WhatsAppButton> createState() => _WhatsAppButtonState();
}

class _WhatsAppButtonState extends State<WhatsAppButton> {
  bool _nudge = false;
  bool _done = false;

  Future<void> _tap() async {
    setState(() => _nudge = true);
    Future.delayed(AMotion.tap, () {
      if (mounted) setState(() => _nudge = false);
    });
    try {
      await widget.onPressed();
      if (!mounted) return;
      setState(() => _done = true);
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      if (mounted) setState(() => _done = false);
    } catch (e) {
      widget.onError?.call(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF1FA855);
    return TapScale(
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
            backgroundColor: green, foregroundColor: Colors.white),
        onPressed: _tap,
        icon: AnimatedSlide(
          offset: Offset(_nudge ? 0.12 : 0, 0), // ≈ 2 px
          duration: AMotion.of(context, AMotion.tap),
          curve: AMotion.out,
          child: AnimatedSwitcher(
            duration: AMotion.of(context, AMotion.tap),
            child: Icon(_done ? Icons.check : Icons.send,
                key: ValueKey(_done), size: 18),
          ),
        ),
        label: Text(_done ? 'Ouvert' : widget.label),
      ),
    );
  }
}
