import 'package:flutter/material.dart';

/// Étape 1 : confirmation. Retourne true si l'utilisateur confirme.
Future<bool> confirmDelete(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Supprimer',
}) async {
  final cs = Theme.of(context).colorScheme;
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Annuler')),
        TextButton(
          style: TextButton.styleFrom(foregroundColor: cs.error),
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return ok == true;
}

/// Étape 2 : suppression "différée" avec possibilité d'annuler.
/// - L'UI retire l'élément tout de suite (RemovableItem, M19).
/// - `onCommit` (la VRAIE suppression en base) n'est appelé qu'à la fermeture
///   du SnackBar si l'utilisateur n'a pas appuyé sur Annuler.
/// - `onUndo` remet l'élément dans l'état de l'UI.
void showUndoSnack(
  BuildContext context, {
  required String message,
  required VoidCallback onUndo,
  required VoidCallback onCommit,
  Duration duration = const Duration(seconds: 5),
}) {
  var undone = false;
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar(); // commit immédiat d'une éventuelle suppression précédente
  messenger
      .showSnackBar(SnackBar(
        content: Text(message),
        duration: duration,
        action: SnackBarAction(
          label: 'Annuler',
          onPressed: () {
            undone = true;
            onUndo();
          },
        ),
      ))
      .closed
      .then((_) {
    if (!undone) onCommit();
  });
}
