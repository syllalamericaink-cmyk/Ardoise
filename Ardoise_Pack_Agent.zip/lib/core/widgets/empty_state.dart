import 'package:flutter/material.dart';
import '../motion/ardoise_motion.dart';
import '../theme/ardoise_shape.dart';

/// M20 — état vide : illustration (fondu + glissement 10 px) puis texte. Une seule fois.
/// Toujours : un titre clair, une phrase d'aide, et UNE action.
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            FadeSlideIn(
              offset: const Offset(0, 10),
              duration: AMotion.hero,
              child: Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  border: Border.all(color: cs.outlineVariant),
                  borderRadius: AShape.rMd,
                ),
                child: Icon(icon, size: 32, color: cs.onSurfaceVariant),
              ),
            ),
            const SizedBox(height: 20),
            FadeSlideIn(
              index: 1,
              offset: const Offset(0, 10),
              duration: AMotion.hero,
              child: Column(
                children: [
                  Text(title,
                      style: tt.titleMedium, textAlign: TextAlign.center),
                  const SizedBox(height: 6),
                  Text(message,
                      style: tt.bodyMedium
                          ?.copyWith(color: cs.onSurfaceVariant),
                      textAlign: TextAlign.center),
                  if (actionLabel != null && onAction != null) ...[
                    const SizedBox(height: 20),
                    TapScale(
                      child: FilledButton(
                          onPressed: onAction, child: Text(actionLabel!)),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
