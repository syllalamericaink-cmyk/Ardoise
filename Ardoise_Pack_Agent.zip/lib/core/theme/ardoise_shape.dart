import 'package:flutter/material.dart';

/// Rayons réduits : look plus net, plus "pro". Maximum 6 px partout.
class AShape {
  AShape._();
  static const double xs = 2; // barres de progression, puces
  static const double sm = 4; // boutons, champs, cartes
  static const double md = 6; // sheets (haut uniquement), dialogs

  static BorderRadius get rSm => BorderRadius.circular(sm);
  static BorderRadius get rMd => BorderRadius.circular(md);
  static const BorderRadius sheetTop =
      BorderRadius.vertical(top: Radius.circular(md));
}

/// Applique les rayons réduits aux composants dont le type de thème est stable
/// entre versions de Flutter. À appeler : `theme = applyArdoiseShape(theme)`.
///
/// ⚠ À FAIRE À LA MAIN selon la version de Flutter (types qui changent) :
///  - cardTheme        (CardTheme ou CardThemeData)       -> RoundedRectangleBorder(AShape.rSm)
///  - dialogTheme      (DialogTheme ou DialogThemeData)   -> RoundedRectangleBorder(AShape.rMd)
///  - inputDecorationTheme : OutlineInputBorder(borderRadius: AShape.rSm) pour
///    border / enabledBorder / focusedBorder / errorBorder
///  - chipTheme / tabBarTheme / navigationBarTheme : indicateurs avec AShape.rSm
ThemeData applyArdoiseShape(ThemeData t) {
  final shape = RoundedRectangleBorder(borderRadius: AShape.rSm);
  return t.copyWith(
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: (t.elevatedButtonTheme.style ?? const ButtonStyle())
          .copyWith(shape: WidgetStatePropertyAll(shape)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: (t.filledButtonTheme.style ?? const ButtonStyle())
          .copyWith(shape: WidgetStatePropertyAll(shape)),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: (t.outlinedButtonTheme.style ?? const ButtonStyle())
          .copyWith(shape: WidgetStatePropertyAll(shape)),
    ),
    textButtonTheme: TextButtonThemeData(
      style: (t.textButtonTheme.style ?? const ButtonStyle())
          .copyWith(shape: WidgetStatePropertyAll(shape)),
    ),
    floatingActionButtonTheme: t.floatingActionButtonTheme.copyWith(
      shape: RoundedRectangleBorder(borderRadius: AShape.rMd),
    ),
    bottomSheetTheme: t.bottomSheetTheme.copyWith(
      shape: const RoundedRectangleBorder(borderRadius: AShape.sheetTop),
    ),
    snackBarTheme: t.snackBarTheme.copyWith(
      shape: shape,
      behavior: SnackBarBehavior.floating,
    ),
  );
}
