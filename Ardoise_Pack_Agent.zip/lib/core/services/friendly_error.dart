import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Transforme une erreur technique en message compréhensible (français).
/// Le détail technique est conservé dans les logs (debugPrint), jamais affiché.
String friendlyError(Object error, {String? action}) {
  debugPrint('[Ardoise] ${action ?? 'erreur'}: $error');
  final raw = error.toString().toLowerCase();
  final prefix = action == null ? '' : '$action impossible. ';

  if (error is TimeoutException) {
    return '${prefix}Cela prend trop de temps. Réessayez.';
  }
  if (error is FormatException) {
    return '${prefix}Une valeur saisie n\'est pas valide. Vérifiez le champ indiqué.';
  }
  if (error is PlatformException) {
    final c = error.code.toLowerCase();
    if (c.contains('permission')) {
      return '${prefix}Autorisez l\'accès dans les réglages du téléphone, puis réessayez.';
    }
    if (c.contains('not_found') || c.contains('activity')) {
      return '${prefix}L\'application nécessaire n\'est pas installée sur ce téléphone.';
    }
  }
  if (error is FileSystemException || raw.contains('no space')) {
    return '${prefix}Espace de stockage insuffisant ou fichier inaccessible.';
  }
  if (raw.contains('database') || raw.contains('sqlite') || raw.contains('locked')) {
    return '${prefix}Vos données n\'ont pas pu être enregistrées. Réessayez dans un instant.';
  }
  if (raw.contains('whatsapp') || raw.contains('could not launch')) {
    return 'WhatsApp n\'a pas pu s\'ouvrir. Vérifiez qu\'il est installé et que le numéro est correct.';
  }
  return '${prefix}Un problème est survenu. Réessayez.';
}

void showFriendlyError(BuildContext context, Object error, {String? action}) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(content: Text(friendlyError(error, action: action))));
}
