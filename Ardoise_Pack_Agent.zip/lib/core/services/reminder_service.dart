import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Un rappel à notifier. À construire à partir des rappels DÉJÀ stockés par l'app
/// (ne pas changer le modèle ni la base : on se contente de les lire).
class ReminderEntry {
  const ReminderEntry({
    required this.key,
    required this.title,
    required this.body,
    required this.when,
    this.payload,
  });

  /// Identifiant stable du rappel (id en base, ou "personId:ligneId").
  final String key;
  final String title;
  final String body;
  final DateTime when;

  /// Ex: "person:42" -> ouvrir la Fiche personne au tap.
  final String? payload;

  /// ID Android stable (32 bits positifs).
  int get notificationId => key.hashCode & 0x7fffffff;
}

/// Alertes locales : la notification se déclenche À L'HEURE du rappel,
/// même app fermée, et est reprogrammée après redémarrage du téléphone
/// (via ScheduledNotificationBootReceiver, voir AndroidManifest).
///
/// ⚠ Écrit pour flutter_local_notifications >= 19. Si la version installée est <= 18,
/// ajouter dans zonedSchedule :
///   uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime
/// ⚠ flutter_timezone >= 4 renvoie un TimezoneInfo (utiliser .identifier) ; avant, un String.
class ReminderService {
  ReminderService._();
  static final ReminderService instance = ReminderService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _ready = false;

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'ardoise_reminders',
      'Rappels',
      channelDescription: 'Rappels de paiements et de dettes',
      importance: Importance.high,
      priority: Priority.high,
      category: AndroidNotificationCategory.reminder,
      visibility: NotificationVisibility.private,
    ),
  );

  /// À appeler dans main() avant runApp().
  /// `onOpen(payload)` : naviguer vers la Fiche personne (pas vers l'Accueil).
  Future<void> init({void Function(String? payload)? onOpen}) async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    try {
      final tzInfo = await FlutterTimezone.getLocalTimezone();
      // flutter_timezone >= 4 : tzInfo.identifier ; < 4 : tzInfo est un String
      tz.setLocalLocation(tz.getLocation(tzInfo.identifier));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Africa/Abidjan'));
    }
    await _plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
      onDidReceiveNotificationResponse: (r) => onOpen?.call(r.payload),
    );
    _ready = true;
  }

  /// Payload de la notification qui a lancé l'app (app fermée -> tap).
  Future<String?> launchPayload() async {
    final d = await _plugin.getNotificationAppLaunchDetails();
    return (d?.didNotificationLaunchApp ?? false)
        ? d?.notificationResponse?.payload
        : null;
  }

  /// Demande les autorisations. À appeler quand l'utilisateur ACTIVE les rappels
  /// (pas au premier lancement). Retourne true si les notifications sont autorisées.
  Future<bool> requestPermissions() async {
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final notif = await android?.requestNotificationsPermission() ?? true;
    // Alarme exacte (Android 12+) : nécessaire pour que l'alerte parte à la minute.
    final exact = await android?.canScheduleExactNotifications() ?? true;
    if (!exact) await android?.requestExactAlarmsPermission();
    return notif;
  }

  Future<bool> _canExact() async {
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    return await android?.canScheduleExactNotifications() ?? false;
  }

  Future<void> schedule(ReminderEntry e) async {
    if (!_ready) return;
    final when = tz.TZDateTime.from(e.when, tz.local);
    if (!when.isAfter(tz.TZDateTime.now(tz.local))) return; // passé : voir fireIfDue
    await _plugin.zonedSchedule(
      e.notificationId,
      e.title,
      e.body,
      when,
      _details,
      androidScheduleMode: await _canExact()
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      payload: e.payload,
    );
  }

  Future<void> cancel(String key) async {
    if (!_ready) return;
    await _plugin.cancel(ReminderEntry(
            key: key, title: '', body: '', when: DateTime.now())
        .notificationId);
  }

  /// Reprogramme TOUS les rappels actifs. À appeler :
  ///  - au démarrage de l'app,
  ///  - au retour au premier plan (WidgetsBindingObserver.resumed),
  ///  - après chaque création / modification / suppression / désactivation de rappel.
  Future<void> syncAll(Iterable<ReminderEntry> active) async {
    if (!_ready) return;
    await _plugin.cancelAll();
    for (final e in active) {
      try {
        await schedule(e);
      } catch (err) {
        debugPrint('[Ardoise] rappel ${e.key}: $err');
      }
    }
  }

  /// Rappel dont l'heure est déjà passée et qui n'a jamais été notifié
  /// (téléphone éteint, app tuée…) : l'afficher tout de suite.
  /// L'app doit mémoriser "déjà notifié" avec SON mécanisme existant, sans changer le modèle
  /// métier (ex. clé SharedPreferences `notified_<key>`).
  Future<void> showNow(ReminderEntry e) async {
    if (!_ready) return;
    await _plugin.show(e.notificationId, e.title, e.body, _details,
        payload: e.payload);
  }
}
