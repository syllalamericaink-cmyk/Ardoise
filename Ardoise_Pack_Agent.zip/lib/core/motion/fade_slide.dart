import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// Apparition unique : opacité 0→1 + glissement (px) → 0, avec décalage (stagger).
/// Joue UNE fois au montage. Utilisé pour M02, M05, M07, M13, M20.
///
/// Dans une ListView.builder, passer `enabled: index < 10` pour ne pas
/// rejouer l'animation quand on refait défiler la liste.
class FadeSlideIn extends StatefulWidget {
  const FadeSlideIn({
    super.key,
    required this.child,
    this.index = 0,
    this.offset = const Offset(0, 18),
    this.duration = AMotion.card,
    this.stagger = AMotion.stagger,
    this.maxStaggered = 8,
    this.enabled = true,
    this.curve = AMotion.outCubic,
  });

  final Widget child;
  final int index;
  final Offset offset;
  final Duration duration;
  final Duration stagger;
  final int maxStaggered;
  final bool enabled;
  final Curve curve;

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this);
  late Animation<double> _a;
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    final steps =
        widget.index < widget.maxStaggered ? widget.index : widget.maxStaggered;
    final delay = widget.stagger * steps;
    final total = widget.duration + delay;
    _c.duration = total;
    final begin = total.inMilliseconds == 0
        ? 0.0
        : delay.inMilliseconds / total.inMilliseconds;
    _a = CurvedAnimation(
      parent: _c,
      curve: Interval(begin, 1.0, curve: widget.curve),
    );
    if (!widget.enabled || AMotion.reduced(context)) {
      _c.value = 1;
    } else {
      _c.forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _a,
      child: widget.child, // construit une seule fois, pas de rebuild
      builder: (context, child) {
        final t = _a.value;
        return Opacity(
          opacity: t,
          child: Transform.translate(
            offset: widget.offset * (1 - t),
            child: child,
          ),
        );
      },
    );
  }
}

/// Petit raccourci : `widget.fadeSlide(index: 2)`.
extension FadeSlideX on Widget {
  Widget fadeSlide({
    int index = 0,
    Offset offset = const Offset(0, 18),
    Duration duration = AMotion.card,
    Duration stagger = AMotion.stagger,
    bool enabled = true,
  }) =>
      FadeSlideIn(
        index: index,
        offset: offset,
        duration: duration,
        stagger: stagger,
        enabled: enabled,
        child: this,
      );
}
