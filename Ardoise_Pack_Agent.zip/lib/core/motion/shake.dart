import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// M18 — secousse du conteneur PIN : -6, +6, -4, +4, 0 px en 220 ms (linéaire).
/// Incrémenter `trigger` à chaque PIN incorrect.
class Shake extends StatefulWidget {
  const Shake({super.key, required this.child, this.trigger = 0});
  final Widget child;
  final int trigger;

  @override
  State<Shake> createState() => _ShakeState();
}

class _ShakeState extends State<Shake> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: AMotion.pinShake);

  late final Animation<double> _dx = TweenSequence<double>([
    _item(0, -6, 1),
    _item(-6, 6, 2),
    _item(6, -4, 2),
    _item(-4, 4, 2),
    _item(4, 0, 1),
  ]).animate(_c);

  static TweenSequenceItem<double> _item(double a, double b, double w) =>
      TweenSequenceItem(
          tween: Tween(begin: a, end: b).chain(CurveTween(curve: Curves.linear)),
          weight: w);

  @override
  void didUpdateWidget(Shake old) {
    super.didUpdateWidget(old);
    if (widget.trigger != old.trigger && !AMotion.reduced(context)) {
      _c.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _dx,
      child: widget.child,
      builder: (_, c) => Transform.translate(offset: Offset(_dx.value, 0), child: c),
    );
  }
}
