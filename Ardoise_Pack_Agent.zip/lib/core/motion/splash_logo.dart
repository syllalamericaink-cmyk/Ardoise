import 'dart:async';
import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// M01 — Splash : opacité 0→1, translateY +14→0, scale 0.96→1 (450 ms, easeOutCubic),
/// puis `onDone` après 380 ms de pause. Utiliser ensuite
/// Navigator.pushReplacement(context, ArdoiseRoute(builder: ..., fadeOnly: true)).
class SplashLogo extends StatefulWidget {
  const SplashLogo({super.key, required this.logo, required this.onDone});
  final Widget logo;
  final VoidCallback onDone;

  @override
  State<SplashLogo> createState() => _SplashLogoState();
}

class _SplashLogoState extends State<SplashLogo>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: AMotion.splash);
  late final Animation<double> _a =
      CurvedAnimation(parent: _c, curve: AMotion.outCubic);
  Timer? _t;
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (AMotion.reduced(context)) {
      _c.value = 1;
      _t = Timer(const Duration(milliseconds: 150), widget.onDone);
    } else {
      _c.forward().then((_) {
        _t = Timer(AMotion.splashHold, () {
          if (mounted) widget.onDone();
        });
      });
    }
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _a,
      child: widget.logo,
      builder: (_, child) => Opacity(
        opacity: _a.value,
        child: Transform.translate(
          offset: Offset(0, 14 * (1 - _a.value)),
          child: Transform.scale(scale: 0.96 + 0.04 * _a.value, child: child),
        ),
      ),
    );
  }
}
