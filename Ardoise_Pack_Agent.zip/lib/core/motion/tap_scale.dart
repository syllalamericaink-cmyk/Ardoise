import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// M03 / M14 — feedback de pression : 1.00 → 0.96 → 1.00 en 160 ms.
/// Utilise un Listener : ne vole AUCUN geste au bouton enfant (InkWell/onPressed intacts).
class TapScale extends StatefulWidget {
  const TapScale({super.key, required this.child, this.scale = 0.96});
  final Widget child;
  final double scale;

  @override
  State<TapScale> createState() => _TapScaleState();
}

class _TapScaleState extends State<TapScale> {
  bool _down = false;

  void _set(bool v) {
    if (_down != v) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _set(true),
      onPointerUp: (_) => _set(false),
      onPointerCancel: (_) => _set(false),
      child: AnimatedScale(
        scale: _down ? widget.scale : 1.0,
        duration: AMotion.of(context, AMotion.tap),
        curve: AMotion.out,
        child: widget.child,
      ),
    );
  }
}
