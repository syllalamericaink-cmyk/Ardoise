import 'package:flutter/material.dart';

/// Skeleton léger : UN seul contrôleur pour tout le groupe, simple pulsation
/// d'opacité, uniquement pendant le chargement (le widget disparaît ensuite).
/// Si animations réduites : bloc statique.
class Skeleton extends StatefulWidget {
  const Skeleton({super.key, required this.child});
  final Widget child;

  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900));
  late final Animation<double> _o = Tween(begin: 0.45, end: 1.0)
      .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (!reduced) _c.repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) =>
      FadeTransition(opacity: _o, child: widget.child);
}

class SkeletonBox extends StatelessWidget {
  const SkeletonBox({super.key, this.width, this.height = 14});
  final double? width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.onSurface.withAlpha(22),
        borderRadius: BorderRadius.circular(3),
      ),
    );
  }
}

/// Squelette d'une ligne "personne" (liste Personnes / Accueil).
class PersonTileSkeleton extends StatelessWidget {
  const PersonTileSkeleton({super.key, this.count = 5});
  final int count;

  @override
  Widget build(BuildContext context) {
    return Skeleton(
      child: Column(
        children: List.generate(
          count,
          (_) => const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                SkeletonBox(width: 40, height: 40),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SkeletonBox(width: 140),
                      SizedBox(height: 8),
                      SkeletonBox(width: 90, height: 10),
                    ],
                  ),
                ),
                SkeletonBox(width: 60),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Squelette des 3 cartes de l'Accueil (À recevoir / À payer / En retard).
class SummarySkeleton extends StatelessWidget {
  const SummarySkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return const Skeleton(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            SkeletonBox(height: 84),
            SizedBox(height: 12),
            Row(children: [
              Expanded(child: SkeletonBox(height: 72)),
              SizedBox(width: 12),
              Expanded(child: SkeletonBox(height: 72)),
            ]),
          ],
        ),
      ),
    );
  }
}
