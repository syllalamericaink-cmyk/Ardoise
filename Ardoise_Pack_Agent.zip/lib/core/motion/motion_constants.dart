import 'package:flutter/material.dart';

/// Tokens issus de ardoise_motion_design.json — SEULE source de vérité
/// pour les durées et courbes. Ne jamais écrire de durée en dur ailleurs.
class AMotion {
  AMotion._();

  static const tap = Duration(milliseconds: 160);
  static const field = Duration(milliseconds: 180);
  static const small = Duration(milliseconds: 250);
  static const card = Duration(milliseconds: 300);
  static const page = Duration(milliseconds: 320);
  static const hero = Duration(milliseconds: 350);
  static const success = Duration(milliseconds: 520);
  static const settled = Duration(milliseconds: 550);
  static const debt = Duration(milliseconds: 600);
  static const chart = Duration(milliseconds: 650);
  static const counter = Duration(milliseconds: 700);
  static const pinShake = Duration(milliseconds: 220);
  static const remove = Duration(milliseconds: 280);
  static const stagger = Duration(milliseconds: 55);
  static const staggerForm = Duration(milliseconds: 45);
  static const splash = Duration(milliseconds: 450);
  static const splashHold = Duration(milliseconds: 380);

  static const outCubic = Curves.easeOutCubic;
  static const inOutCubic = Curves.easeInOutCubic;
  static const out = Curves.easeOut;
  static const inOut = Curves.easeInOut;
  static const outBack = Curves.easeOutBack;

  /// Vrai si l'utilisateur a désactivé les animations (Android: "Supprimer les animations").
  static bool reduced(BuildContext context) =>
      MediaQuery.maybeOf(context)?.disableAnimations ?? false;

  /// Durée effective : zéro si animations réduites.
  static Duration of(BuildContext context, Duration d) =>
      reduced(context) ? Duration.zero : d;
}
