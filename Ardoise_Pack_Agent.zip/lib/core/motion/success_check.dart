import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// M10 (paiement enregistré) et M12 (dette soldée).
/// Joue une seule fois. Aucune boucle, aucun confetti permanent.
class SuccessCheck extends StatefulWidget {
  const SuccessCheck({
    super.key,
    required this.color,
    this.label,
    this.size = 56,
    this.settled = false, // true = M12 (0.75→1.05→1, 550 ms)
    this.halo = true,
  });

  final Color color;
  final String? label;
  final double size;
  final bool settled;
  final bool halo;

  @override
  State<SuccessCheck> createState() => _SuccessCheckState();
}

class _SuccessCheckState extends State<SuccessCheck>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: widget.settled ? AMotion.settled : AMotion.success,
  );
  late final Animation<double> _scale;
  late final Animation<double> _fade;
  late final Animation<double> _text;
  late final Animation<double> _halo;
  bool _started = false;

  @override
  void initState() {
    super.initState();
    final from = widget.settled ? 0.75 : 0.70;
    final peak = widget.settled ? 1.05 : 1.08;
    _scale = TweenSequence<double>([
      TweenSequenceItem(
          tween: Tween(begin: from, end: peak)
              .chain(CurveTween(curve: Curves.easeOut)),
          weight: 60),
      TweenSequenceItem(
          tween: Tween(begin: peak, end: 1.0)
              .chain(CurveTween(curve: Curves.easeInOut)),
          weight: 40),
    ]).animate(_c);
    _fade = CurvedAnimation(parent: _c, curve: const Interval(0, 0.4));
    _text = CurvedAnimation(
        parent: _c, curve: const Interval(0.3, 1, curve: AMotion.outCubic));
    _halo = CurvedAnimation(
        parent: _c, curve: const Interval(0.2, 1, curve: Curves.easeOut));
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (AMotion.reduced(context)) {
      _c.value = 1;
    } else {
      _c.forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    final radius = BorderRadius.circular(s * 0.14);
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: s * 1.6,
              height: s * 1.6,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  if (widget.halo)
                    Opacity(
                      opacity: (0.22 * (1 - _halo.value)).clamp(0.0, 1.0),
                      child: Transform.scale(
                        scale: 1 + 0.5 * _halo.value,
                        child: Container(
                          width: s,
                          height: s,
                          decoration: BoxDecoration(
                              color: widget.color, borderRadius: radius),
                        ),
                      ),
                    ),
                  Opacity(
                    opacity: _fade.value,
                    child: Transform.scale(
                      scale: _scale.value,
                      child: Container(
                        width: s,
                        height: s,
                        decoration: BoxDecoration(
                            color: widget.color, borderRadius: radius),
                        child: Icon(Icons.check,
                            color: Colors.white, size: s * 0.6),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (widget.label != null)
              Opacity(
                opacity: _text.value,
                child: Transform.translate(
                  offset: Offset(0, 8 * (1 - _text.value)),
                  child: Text(
                    widget.label!,
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(color: widget.color),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}
