import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// M19 — disparition d'un élément : opacité 1→0 + hauteur 1→0 en 280 ms.
/// Les éléments suivants remontent naturellement (SizeTransition).
///
/// Usage : passer `removed: true` quand l'utilisateur a CONFIRMÉ.
/// `onRemoved` est appelé à la fin de l'animation (retirer alors l'élément de la liste d'état).
class RemovableItem extends StatefulWidget {
  const RemovableItem({
    super.key,
    required this.child,
    required this.removed,
    this.onRemoved,
  });

  final Widget child;
  final bool removed;
  final VoidCallback? onRemoved;

  @override
  State<RemovableItem> createState() => _RemovableItemState();
}

class _RemovableItemState extends State<RemovableItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: AMotion.remove, value: 1.0);
  late final Animation<double> _a =
      CurvedAnimation(parent: _c, curve: AMotion.inOut);

  @override
  void didUpdateWidget(RemovableItem old) {
    super.didUpdateWidget(old);
    if (!old.removed && widget.removed) {
      if (AMotion.reduced(context)) {
        _c.value = 0;
        widget.onRemoved?.call();
      } else {
        _c.reverse().then((_) {
          if (mounted) widget.onRemoved?.call();
        });
      }
    } else if (old.removed && !widget.removed) {
      // Annulation (Undo) : l'élément revient.
      _c.forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizeTransition(
      sizeFactor: _a,
      axisAlignment: -1,
      child: FadeTransition(opacity: _a, child: widget.child),
    );
  }
}
