import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// M11 / M15 — compteur monétaire interpolé.
/// 1er affichage : 0 → value. Mise à jour : ancienne valeur → nouvelle valeur.
/// `format` = le formateur d'argent DÉJÀ utilisé par l'app (ex: "12 500 FCFA").
/// La valeur métier n'est jamais modifiée : on n'anime que l'affichage.
class AnimatedAmount extends StatelessWidget {
  const AnimatedAmount({
    super.key,
    required this.value,
    required this.format,
    this.style,
    this.duration = AMotion.debt,
    this.curve = AMotion.inOutCubic,
  });

  final num value;
  final String Function(num) format;
  final TextStyle? style;
  final Duration duration;
  final Curve curve;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: value.toDouble()),
      duration: AMotion.of(context, duration),
      curve: curve,
      builder: (_, v, __) => Text(format(v.roundToDouble()), style: style),
    );
  }
}

/// M11 — barre de progression de dette (angles quasi droits).
class DebtProgressBar extends StatelessWidget {
  const DebtProgressBar({
    super.key,
    required this.progress,
    required this.color,
    required this.trackColor,
    this.height = 6,
  });

  final double progress; // 0..1 (payé / total)
  final Color color;
  final Color trackColor;
  final double height;

  @override
  Widget build(BuildContext context) {
    final target = progress.clamp(0.0, 1.0).toDouble();
    return RepaintBoundary(
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: target),
        duration: AMotion.of(context, AMotion.debt),
        curve: AMotion.inOutCubic,
        builder: (_, v, __) => ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: Container(
            height: height,
            color: trackColor,
            alignment: Alignment.centerLeft,
            child: FractionallySizedBox(
              widthFactor: v,
              child: Container(color: color),
            ),
          ),
        ),
      ),
    );
  }
}
