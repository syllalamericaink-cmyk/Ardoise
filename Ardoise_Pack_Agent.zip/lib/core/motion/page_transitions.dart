import 'package:flutter/material.dart';
import 'motion_constants.dart';

Widget _slideFade(
  BuildContext context,
  Animation<double> animation,
  Widget child, {
  double dx = 18,
}) {
  if (AMotion.reduced(context)) return child;
  final curved = CurvedAnimation(
    parent: animation,
    curve: AMotion.outCubic,
    reverseCurve: Curves.easeInCubic,
  );
  // La page précédente reste stable : on n'utilise pas secondaryAnimation.
  return FadeTransition(
    opacity: curved,
    child: AnimatedBuilder(
      animation: curved,
      child: child,
      builder: (_, c) =>
          Transform.translate(offset: Offset(dx * (1 - curved.value), 0), child: c),
    ),
  );
}

/// M04 — à brancher UNE fois dans le ThemeData :
/// ThemeData(pageTransitionsTheme: ardoisePageTransitions)
/// Toutes les MaterialPageRoute existantes en bénéficient sans toucher à la navigation.
class ArdoisePageTransitionsBuilder extends PageTransitionsBuilder {
  const ArdoisePageTransitionsBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) =>
      _slideFade(context, animation, child);
}

const ardoisePageTransitions = PageTransitionsTheme(
  builders: {
    TargetPlatform.android: ArdoisePageTransitionsBuilder(),
    TargetPlatform.iOS: ArdoisePageTransitionsBuilder(),
  },
);

/// Route explicite (320 ms) pour les cas où on veut maîtriser la durée.
/// `fadeOnly: true` pour Splash → Accueil.
class ArdoiseRoute<T> extends PageRouteBuilder<T> {
  ArdoiseRoute({
    required WidgetBuilder builder,
    super.settings,
    bool fadeOnly = false,
  }) : super(
          transitionDuration: AMotion.page,
          reverseTransitionDuration: AMotion.small,
          pageBuilder: (context, _, __) => builder(context),
          transitionsBuilder: (context, animation, _, child) {
            if (fadeOnly) {
              if (AMotion.reduced(context)) return child;
              return FadeTransition(
                opacity: CurvedAnimation(
                    parent: animation, curve: AMotion.outCubic),
                child: child,
              );
            }
            return _slideFade(context, animation, child);
          },
        );
}

/// M09 — Bottom sheet (paiement, ajout…) : montée 300 ms, scrim 0.35, contenu en fondu.
Future<T?> showArdoiseSheet<T>({
  required BuildContext context,
  required WidgetBuilder builder,
  bool isScrollControlled = true,
}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: isScrollControlled,
    useSafeArea: true,
    barrierColor: const Color(0x59000000), // 0.35
    sheetAnimationStyle: AnimationStyle(
      duration: AMotion.card,
      reverseDuration: AMotion.small,
      curve: AMotion.outCubic,
      reverseCurve: Curves.easeInCubic,
    ),
    builder: (ctx) => _SheetFade(child: builder(ctx)),
  );
}

class _SheetFade extends StatelessWidget {
  const _SheetFade({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: AMotion.reduced(context) ? 1 : 0, end: 1),
      duration: AMotion.card,
      curve: AMotion.outCubic,
      builder: (_, v, c) => Opacity(opacity: v, child: c),
      child: child,
    );
  }
}
