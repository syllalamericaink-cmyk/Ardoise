import 'package:flutter/material.dart';
import 'motion_constants.dart';

/// M08 — à envelopper autour d'un TextField/TextFormField :
/// léger relèvement de 1 px à la prise de focus (180 ms).
/// La bordure/label actifs restent gérés par InputDecorationTheme
/// (focusedBorder), que Flutter anime déjà nativement (~167 ms).
class FocusLift extends StatefulWidget {
  const FocusLift({super.key, required this.child});
  final Widget child;

  @override
  State<FocusLift> createState() => _FocusLiftState();
}

class _FocusLiftState extends State<FocusLift> {
  bool _focused = false;

  @override
  Widget build(BuildContext context) {
    return Focus(
      canRequestFocus: false,
      skipTraversal: true,
      onFocusChange: (f) => setState(() => _focused = f),
      child: AnimatedContainer(
        duration: AMotion.of(context, AMotion.field),
        curve: AMotion.out,
        transform: Matrix4.translationValues(0, _focused ? -1 : 0, 0),
        child: widget.child,
      ),
    );
  }
}
